#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> // For sleep function
#include <fcntl.h>  // For open()
#include <termios.h> // For struct termios
#include <string.h> // For strlen()

// Function to open serial port
int openSerialPort(const char *portName) {
    int fd = open(portName, O_RDWR | O_NOCTTY | O_NDELAY);
    if (fd == -1) {
        perror("Unable to open serial port");
    }
    return fd;
}

// Function to configure serial port
void configureSerialPort(int fd) {
    struct termios options;
    tcgetattr(fd, &options);
    options.c_cflag = B9600 | CS8 | CLOCAL | CREAD; // Set baud rate and other options
    options.c_iflag = IGNPAR; // Ignore framing errors
    options.c_oflag = 0; // Raw output
    options.c_lflag = 0; // Raw input
    tcflush(fd, TCIFLUSH);
    tcsetattr(fd, TCSANOW, &options);
}

void startVendingMachine(int serialPort) {
    printf("Vending Machine Activated!\n");
    printf("Sanitizing products... You have 1 minute.\n");

    // Send command to Arduino to start the sensor
    write(serialPort, "S", 1); // Send 'S' to start sanitization

    // Countdown from 60 seconds
    for (int i = 60; i > 0; i--) {
        printf("\rSanitization in progress: %d seconds remaining...   ", i); // Extra spaces to clear previous output
        fflush(stdout); // Ensure the output is printed immediately
        sleep(1); // Wait for 1 second
    }

    printf("\rSanitization complete! The vending machine is now deactivated.\n");
}

int main() {
    float payment;
    const char *serialPortName = "/dev/ttyUSB0"; // Change this to your Arduino's port

    int serialPort = openSerialPort(serialPortName);
    if (serialPort == -1) {
        return 1; // Exit if unable to open serial port
    }
    configureSerialPort(serialPort);

    printf("Please insert payment (amount in rupees): ");
    scanf("%f", &payment);

    // Check if payment is exactly 10 rupees
    if (payment == 10.0) {
        printf("Payment accepted: ₹%.2f\n", payment);
        startVendingMachine(serialPort);
    } else {
        printf("Invalid payment. Please insert exactly 10 rupees.\n");
    }

    close(serialPort); // Close the serial port
    return 0;
}